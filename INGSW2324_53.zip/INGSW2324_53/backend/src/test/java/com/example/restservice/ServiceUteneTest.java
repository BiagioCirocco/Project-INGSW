package com.example.restservice;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dao.interfaces.UtenteDAO;
import com.entity.Utente;
import com.service.ServiceAccesso;

public class ServiceUteneTest {

    @Mock
    UtenteDAO utenteDAO;

    @InjectMocks
    ServiceAccesso serviceAccesso;


    @Test
    public void testEffettuaAccesso() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(utenteDAO.accedi(any(Utente.class))).thenReturn(true);

        // ACT
        Boolean result = serviceAccesso.effettuaAccesso("Fabrizio1", "password");

        // ASSERT
        assertTrue(result);
    }

    @Test
    public void testEffettuaAccessoConNicknameNullo() {
        //ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(utenteDAO.accedi(any(Utente.class))).thenReturn(false);

        // ACT
        Boolean result = serviceAccesso.effettuaAccesso(null, "password");

        //ASSERT
        assertFalse(result);
    }

    @Test
    public void testEffettuaAccessoConPasswordNulla() {
        //ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(utenteDAO.accedi(any(Utente.class))).thenReturn(false);

        // ACT
        Boolean result = serviceAccesso.effettuaAccesso("Fabrizio1", null);

        //ASSERT
        assertFalse(result);
    }

}
