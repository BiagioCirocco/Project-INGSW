package com.example.restservice;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dao.interfaces.AstaInversaDAO;
import com.entity.AstaInversa;
import com.entity.abstracts.Asta;
import com.service.ServiceAstaInversa;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

public class ServiceAstaInversaTest {

    @Mock
    AstaInversaDAO astadao;

    @InjectMocks
    ServiceAstaInversa service;

    @Test
    public void testOttieniAste() {

        //FASE DI ARRANGE

        // Inizializzao gli oggetti astadao e service (quelli con @Mock @InjectMocks)
        MockitoAnnotations.openMocks(this);

        // Creo dei dati fasulli di test
        Asta asta1 = new AstaInversa();
        Asta asta2 = new AstaInversa();
        List<Asta> astaList = Arrays.asList(asta1, asta2);

        // Configuro il mock del DAO per restituire i dati di test
        when(astadao.ottieniAste()).thenReturn(astaList);

        //FASE DI ACT
        List<Asta> result = service.ottieniAste("Tutte", "");
       

        //FASE DI ASSERT
        assertEquals(astaList, result);
    }

    @Test
    public void testOttieniAsteConTitolo() {
        
        //ARRANGE
        MockitoAnnotations.openMocks(this);

    
        Asta asta1 = new AstaInversa();
        Asta asta2 = new AstaInversa();
        List<Asta> astaList = Arrays.asList(asta1, asta2);

       
        when(astadao.ottieniAsteTitolo("Prova")).thenReturn(astaList);

        //ACT
        List<Asta> result = service.ottieniAste("Tutte", "Prova");
       

        //ASSERT
        assertEquals(astaList, result);
    }

    @Test
    public void testOttieniAsteConCategoriaNulla() {
        // ARRANGE
        MockitoAnnotations.openMocks(this);

    

        
        when(astadao.ottieniAsteCategorie(null)).thenReturn(null);

        // ACT
        List<Asta> result = service.ottieniAste(null, "");
       

        //ASSERT
        assertNull( result);
    }

    @Test
    public void testOttieniAsteConCategoriaVuota() {
        // ARRANGE
        MockitoAnnotations.openMocks(this);

    

        
        when(astadao.ottieniAsteCategorie("")).thenReturn(null);

        // ACT
        List<Asta> result = service.ottieniAste("", "");
       

        //ASSERT
        assertNull( result);
    }

    @Test
    public void testOttieniAsteConTitoloNull() {
        // ARRANGE
        MockitoAnnotations.openMocks(this);

    

        
        when(astadao.ottieniAsteCategorie("Elettronica")).thenReturn(null);

        // ACT
        List<Asta> result = service.ottieniAste("Elettronica", null);
       

        //ASSERT
        assertNull( result);
    }

    @Test
    public void testOttieniAsteConCategoriaETitolo() {
        // ARRANGE
        MockitoAnnotations.openMocks(this);

    
        Asta asta1 = new AstaInversa();
        Asta asta2 = new AstaInversa();
        List<Asta> astaList = Arrays.asList(asta1, asta2);

        
        when(astadao.ottieniAsteCategoriaTitolo("Elettronica","Prova")).thenReturn(astaList);

        // ACT
        List<Asta> result = service.ottieniAste("Elettronica", "Prova");
       

        //ASSERT
        assertEquals(astaList, result);
    }
}