package com.example.restservice;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dao.interfaces.AstaSilenziosaDAO;
import com.entity.AstaSilenziosa;
import com.entity.Utente;
import com.service.ServiceAstaSilenziosa;

public class ServiceAstaSilenziosaTest {

    @Mock
    AstaSilenziosaDAO astadao;

    @InjectMocks
    ServiceAstaSilenziosa service;

     @Test
    public void testCreaAsta() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaDaUtente(any(Utente.class))).thenReturn(1);

      
        Map<String, String> params = new HashMap<>();
        params.put("nickname", "test");
        params.put("titolo", "test");
        params.put("categoria", "Elettronica");
        params.put("descrizione", "test");
        params.put("scadenza", "2025-12-31 11:22:00");
        params.put("immagine", "");

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertEquals(Integer.valueOf(1), result);

    }

    @Test
    public void testCreaAstaConImmagine() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaConImmagine(any(Utente.class))).thenReturn(1);

      
        Map<String, String> params = new HashMap<>();
        params.put("nickname", "test");
        params.put("titolo", "test");
        params.put("categoria", "Elettronica");
        params.put("descrizione", "test");
        params.put("scadenza", "2025-12-31 11:22:00");
        params.put("immagine", "mybase64image");

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertEquals(Integer.valueOf(1), result);

    }


    @Test
    public void testCreaAstaConNicknameNullo() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaDaUtente(any(Utente.class))).thenReturn(null);

      
        Map<String, String> params = new HashMap<>();
        params.put("nickname", null);
        params.put("titolo", "test");
        params.put("categoria", "Elettronica");
        params.put("descrizione", "test");
        params.put("scadenza", "2025-12-31 11:22:00");
        params.put("immagine", "");

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertNull(result);

    }

    @Test
    public void testCreaAstaConTitoloNullo() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaDaUtente(any(Utente.class))).thenReturn(null);

      
        Map<String, String> params = new HashMap<>();
        params.put("nickname", "test");
        params.put("titolo", null);
        params.put("categoria", "Elettronica");
        params.put("descrizione", "test");
        params.put("scadenza", "2025-12-31 11:22:00");
        params.put("immagine", "");

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertNull(result);

    }

    @Test
    public void testCreaAstaConCategoriaNulla() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaDaUtente(any(Utente.class))).thenReturn(null);

      
        Map<String, String> params = new HashMap<>();
        params.put("nickname", "test");
        params.put("titolo", "test");
        params.put("categoria", null);
        params.put("descrizione", "test");
        params.put("scadenza", "2025-12-31 11:22:00");
        params.put("immagine", "");

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertNull(result);

    }

    @Test
    public void testCreaAstaConDescrizioneNulla() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaDaUtente(any(Utente.class))).thenReturn(null);

      
        Map<String, String> params = new HashMap<>();
        params.put("nickname", "test");
        params.put("titolo", "test");
        params.put("categoria", "Elettronica");
        params.put("descrizione", null);
        params.put("scadenza", "2025-12-31 11:22:00");
        params.put("immagine", "");

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertNull(result);

    }

    @Test
    public void testCreaAstaConScadenzaNulla() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaDaUtente(any(Utente.class))).thenReturn(null);

      
        Map<String, String> params = new HashMap<>();
        params.put("nickname", "test");
        params.put("titolo", "test");
        params.put("categoria", "Elettronica");
        params.put("descrizione", "test");
        params.put("scadenza", null);
        params.put("immagine", "");

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertNull(result);

    }

    @Test
    public void testCreaAstaConImmagineNulla() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaDaUtente(any(Utente.class))).thenReturn(null);

      
        Map<String, String> params = new HashMap<>();
        params.put("nickname", "test");
        params.put("titolo", "test");
        params.put("categoria", "Elettronica");
        params.put("descrizione", "test");
        params.put("scadenza", "2025-12-31 11:22:00");
        params.put("immagine", null);

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertNull(result);

    }

    @Test
    public void testCreaAstaConScadenzaInferioreAQuellaCorrente() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

       
        when(astadao.creaNuovaAstaDaUtente(any(Utente.class))).thenReturn(null);

        Instant timestamp = Instant.now().minusSeconds(1);
        Map<String, String> params = new HashMap<>();
        params.put("nickname", "test");
        params.put("titolo", "test");
        params.put("categoria", "Elettronica");
        params.put("descrizione", "test");
        params.put("scadenza", timestamp.toString());
        params.put("immagine", null);

        // ACT
        Integer result = service.creaAsta(params);

        // ASSERT
        assertNull(result);

    }

      
    @Test
    public void testInviaOffertaSilenziosa() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

        
        when(astadao.inviaOffertaSilenziosa(any(AstaSilenziosa.class))).thenReturn(true);

       // ACT
        Boolean result = service.inviaOffertaSilenziosa("test", 1, 100.0f);

        // ASSERT
        assertTrue(result);

       
    }

    @Test
    public void testInviaOffertaSilenziosaConNicknameNullo() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

        
        when(astadao.inviaOffertaSilenziosa(any(AstaSilenziosa.class))).thenReturn(false);

       // ACT
        Boolean result = service.inviaOffertaSilenziosa(null, 1, 100.0f);

        // ASSERT
        assertFalse(result);

       
    }

    @Test
    public void testInviaOffertaSilenziosaConIdNegativo() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

        
        when(astadao.inviaOffertaSilenziosa(any(AstaSilenziosa.class))).thenReturn(false);

       // ACT
        Boolean result = service.inviaOffertaSilenziosa("test", -1, 100.0f);

        // ASSERT
        assertFalse(result);

       
    }

    @Test
    public void testInviaOffertaSilenziosaConIdNullo() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

        
        when(astadao.inviaOffertaSilenziosa(any(AstaSilenziosa.class))).thenReturn(false);

       // ACT
        Boolean result = service.inviaOffertaSilenziosa("test", null, 100.0f);

        // ASSERT
        assertFalse(result);

       
    }

    @Test
    public void testInviaOffertaSilenziosaConOffertaNegativa() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

        
        when(astadao.inviaOffertaSilenziosa(any(AstaSilenziosa.class))).thenReturn(false);

       // ACT
        Boolean result = service.inviaOffertaSilenziosa("test", 1, -1f);

        // ASSERT
        assertFalse(result);

       
    }

    @Test
    public void testInviaOffertaSilenziosaConOffertaNulla() {
         // ARRANGE
        MockitoAnnotations.openMocks(this);

        
        when(astadao.inviaOffertaSilenziosa(any(AstaSilenziosa.class))).thenReturn(false);

       // ACT
        Boolean result = service.inviaOffertaSilenziosa("test", 1, null);

        // ASSERT
        assertFalse(result);

       
    }
}
