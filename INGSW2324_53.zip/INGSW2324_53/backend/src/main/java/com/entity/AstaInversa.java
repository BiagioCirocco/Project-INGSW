package com.entity;

import java.sql.Timestamp;

import com.entity.abstracts.Asta;

public class AstaInversa extends Asta {

    private Timestamp scadenza;
    private Float prezzoDiPartenza;

    public AstaInversa(String titolo, String immagine, String categoria, int id) {

        this.titolo = titolo;
        this.immagine = immagine;
        this.categoria = categoria;

        this.id = id;

    }

    public AstaInversa(String titolo, String categoria, Timestamp scadenza, String descrizione,
            float prezzodipartenza) {

        this.titolo = titolo;
        this.categoria = categoria;
        this.descrizione = descrizione;
        this.scadenza = scadenza;
        this.prezzoDiPartenza = prezzodipartenza;
    }


    public AstaInversa(Integer idAsta) {
       this.id=idAsta;
    }

    public AstaInversa() {
        
    }

    public Timestamp getScadenza() {
        return scadenza;
    }

    public Float getPrezzoDiPartenza() {
        return prezzoDiPartenza;
    }

    public void setScadenza(Timestamp scadenza) {

        this.scadenza = scadenza;
    }

    public void setPrezzoDiPartenza(Float prezzoDiPartenza) {
        this.prezzoDiPartenza = prezzoDiPartenza;
    }

}
