package com.entity;

import com.entity.abstracts.OffertaAsta;

public class OffertaAstaInversa extends OffertaAsta {

    public OffertaAstaInversa(float valore) {

        this.valore = valore;
    }

}
