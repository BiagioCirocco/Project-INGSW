package com.entity.abstracts;

import java.util.ArrayList;
import java.util.List;

import com.entity.Utente;

public abstract class Asta {

    protected String titolo;
    protected String immagine;
    protected String descrizione;
    protected String categoria;
    protected Integer id;
    protected Utente utente;
    protected List<OffertaAsta> offerta = new ArrayList<>();

    public String getTitolo() {
        return titolo;
    }

    public String getImmagine() {
        return immagine;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public String getCategoria() {
        return categoria;
    }

    public int getId() {
        return id;
    }

    public List<OffertaAsta> getOfferta() {
        return offerta;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public void setImmagine(String immagine) {
        this.immagine = immagine;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setOfferta(List<OffertaAsta> offerta) {
        this.offerta = offerta;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

}
