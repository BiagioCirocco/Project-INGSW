package com.entity;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.entity.abstracts.Asta;

public class Utente {

    private String email;
    private String nickname;
    private String password;
    private Date dataDiNascita;
    private String sesso;
    private String biografia;
    private String linkLinkedin;
    private String linkInstagram;
    private String linkFacebook;
    private String linkTwitter;
    private Date iscrittoDal;
    private String areaGeografica;

    private List<Asta> asta = new ArrayList<>();

    public Utente(String email2, String password2, String areageografica2, String nickname2,
            Date datadinascita2, String sesso2, String biografia2) {

        email = email2;
        password = password2;
        areaGeografica = areageografica2;
        nickname = nickname2;
        dataDiNascita = datadinascita2;
        sesso = sesso2;
        biografia = biografia2;

    }

    public Utente(String nickname2, String password2) {
        nickname = nickname2;
        password = password2;
    }

    public Utente(String nickname2, String email,String password2, String areageografica2, String biografia2) {
        nickname = nickname2;
        password = password2;
        areaGeografica = areageografica2;
        biografia = biografia2;
        this.email = email;

    }

    public Utente(String nickname2) {
        nickname = nickname2;
    }

    public String getEmail() {
        return email;
    }

    public String getNickname() {
        return nickname;
    }

    public String getPassword() {
        return password;
    }

    public Date getDataDiNascita() {
        return dataDiNascita;
    }

    public String getSesso() {
        return sesso;
    }

    public String getBiografia() {
        return biografia;
    }

    public String getLinkLinkedin() {
        return linkLinkedin;
    }

    public String getLinkInstagram() {
        return linkInstagram;
    }

    public String getLinkFacebook() {
        return linkFacebook;
    }

    public String getLinkTwitter() {
        return linkTwitter;
    }

    public Date getIscrittoDal() {
        return iscrittoDal;
    }

    public String getAreaGeografica() {
        return areaGeografica;
    }

    public List<Asta> getAsta() {
        return asta;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setDataDiNascita(Date dataDiNascita) {
        this.dataDiNascita = dataDiNascita;
    }

    public void setSesso(String sesso) {
        this.sesso = sesso;
    }

    public void setBiografia(String biografia) {
        this.biografia = biografia;
    }

    public void setLinkLinkedin(String linkLinkedin) {
        this.linkLinkedin = linkLinkedin;
    }

    public void setLinkInstagram(String linkInstagram) {
        this.linkInstagram = linkInstagram;
    }

    public void setLinkFacebook(String linkFacebook) {
        this.linkFacebook = linkFacebook;
    }

    public void setLinkTwitter(String linkTwitter) {
        this.linkTwitter = linkTwitter;
    }

    public void setIscrittoDal(Date iscrittoDal) {
        this.iscrittoDal = iscrittoDal;
    }

    public void setAreaGeografica(String areaGeografica) {
        this.areaGeografica = areaGeografica;
    }

    public void setAsta(List<Asta> asta) {
        this.asta = asta;
    }

}
