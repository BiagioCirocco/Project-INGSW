package com.entity.abstracts;

import java.sql.Date;

import com.entity.Utente;

public abstract class OffertaAsta {

    protected Date data;
    protected Float valore;
    protected Utente utente;
    protected Integer idOfferta;

    public Date getData() {
        return data;
    }

    public Float getValore() {
        return valore;
    }

    public Utente getUtente() {
        return utente;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public void setValore(Float valore) {
        this.valore = valore;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public int getIdOfferta() {
        return idOfferta;
    }

    public void setIdOfferta(int idOfferta) {
        this.idOfferta = idOfferta;
    }

}
