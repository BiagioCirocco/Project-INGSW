package com.entity;

import java.sql.Timestamp;

import com.entity.abstracts.Asta;

public class AstaSilenziosa extends Asta {

    private Timestamp scadenza;

    public AstaSilenziosa(String titolo, String immagine, String categoria, int id) {

        this.titolo = titolo;
        this.immagine = immagine;
        this.categoria = categoria;

        this.id = id;
    }

    public Timestamp getScadenza() {
        return scadenza;
    }

    public AstaSilenziosa(String titolo, String categoria, String descrizione, Timestamp scadenza) {

        this.titolo = titolo;
        this.categoria = categoria;
        this.descrizione = descrizione;
        this.scadenza = scadenza;
    }

    public AstaSilenziosa() {
    }



    public AstaSilenziosa(Integer idAsta) {
        this.id=idAsta;
    }

    public void setScadenza(Timestamp scadenza) {
        this.scadenza = scadenza;
    }

}
