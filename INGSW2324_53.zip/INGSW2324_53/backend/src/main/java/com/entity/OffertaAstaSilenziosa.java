package com.entity;

import com.entity.abstracts.OffertaAsta;

public class OffertaAstaSilenziosa extends OffertaAsta {

    private String accettata;

    public OffertaAstaSilenziosa(float valore) {

        this.valore = valore;
    }

    public OffertaAstaSilenziosa(int idOfferta) {

        this.idOfferta = idOfferta;
    }

    public OffertaAstaSilenziosa(float valore, Utente utente, int id) {

        this.valore = valore;
        this.utente = utente;
        this.idOfferta = id;
    }

    public String getAccettata() {
        return accettata;
    }

    public void setAccettata() {
        accettata = "si";
    }
}
