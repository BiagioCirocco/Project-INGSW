package com.controller.interfaces;

import java.util.Map;

public interface ControllerAsta<T> {

    public T creaNuovaAsta(Map<String, String> parametri);

    public T ottieniInformazioniAsta(Integer idAsta);

    public T ottieniInformazioniMiaAsta(Integer idAsta);

    public T ottieniCategorie();

    public T ottieniAste( String categoria, String titolo);

    public T ottieniAggiornamenti(String nickname);

    public T  ottieniImmagineAsta(String filename);

    

}
