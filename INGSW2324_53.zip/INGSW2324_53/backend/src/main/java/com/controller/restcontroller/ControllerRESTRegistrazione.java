package com.controller.restcontroller;

import java.util.Date;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.controller.interfaces.ControllerRegistrazione;
import com.service.ServiceRegistrazione;

@RestController
public class ControllerRESTRegistrazione implements ControllerRegistrazione<Object>{

  private ServiceRegistrazione serviceregistrazione = new ServiceRegistrazione();
  @Override
  @PostMapping("/registrati")
   public ResponseEntity<Map<String, Boolean>> richiediRegistrazione(
      @RequestParam(value = "email", required = true) String email,
      @RequestParam(value = "password", required = true) String password,
      @RequestParam(value = "area_geografica", required = true) String areageografica,
      @RequestParam(value = "nickname", required = true) String nickname,
      @RequestParam(value = "data_di_nascita", required = true) @DateTimeFormat(pattern="yyyy-MM-dd") Date dataDiNascita,
      @RequestParam(value = "sesso", required = true) String sesso,
      @RequestParam(value = "biografia", required = true) String biografia) {

    int statusCode = 200;

    Boolean status = serviceregistrazione.effettuaRegistrazione(email, password, areageografica, nickname,
        dataDiNascita,
        sesso, biografia);


    if (Boolean.FALSE.equals(status)) {
      statusCode = 400;
    }

    return ResponseEntity.status(statusCode).body( Map.of("status", status));

  }

}