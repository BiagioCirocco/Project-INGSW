package com.controller.restcontroller;

import java.util.List;
import java.util.Map;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.controller.interfaces.ControllerAstaInversa;
import com.entity.AstaInversa;
import com.entity.abstracts.Asta;
import com.service.ServiceAstaInversa;

@RestController
public class ControllerRESTAstaInversa implements ControllerAstaInversa<Object> {

    
    private ServiceAstaInversa serviceasta = new ServiceAstaInversa();

    @PostMapping("/crea_nuova_asta_inversa")
    @Override
    public ResponseEntity<Map<String, Integer>> creaNuovaAsta(@RequestParam Map<String, String> params) {

       
        int statusCode = 200;
        Integer status = serviceasta.creaAsta(params);
        if (status==null) {
            statusCode = 400;
        }

        return ResponseEntity.status(statusCode).body(Map.of("status",status));
    }

    @GetMapping("/informazioni_asta_inversa/{idAsta}")
    @Override
    public Map<String, AstaInversa> ottieniInformazioniAsta(@PathVariable Integer idAsta) {

     
        return  Map.of("informazioni", serviceasta.informazioniAsta(idAsta));
    }

    @GetMapping("/informazioni_mia_asta_inversa/{idAsta}")
    @Override
    public Map<String, AstaInversa> ottieniInformazioniMiaAsta(@PathVariable Integer idAsta) {

        return  Map.of("informazioni",serviceasta.informazioniMiaAsta(idAsta));
    }



    @Override
    @GetMapping("/aste_inverse")
    public Map<String, List<Asta>> ottieniAste(@RequestParam(value = "categoria", required = false) String categoria,@RequestParam(value = "search", required = false) String titolo) {

       
        return  Map.of("aste",serviceasta.ottieniAste(categoria,titolo));

    }

    @GetMapping("/ottieni_categorie_inversa")
    @Override
    public Map<String, List<String>> ottieniCategorie() {
        return  Map.of("categorie",serviceasta.ottieniCategorie());
    }

    @GetMapping("/aggiornamenti_inversa/{nickname}")
    @Override
    public Map<String, List<Asta>> ottieniAggiornamenti(@PathVariable String nickname) {

        return  Map.of("aggiornamenti",serviceasta.ottieniAsteVinte(nickname));
    }

    @PostMapping("/invia_offerta_inversa")
    @Override
    public ResponseEntity<Map<String, Boolean>> inviaOfferta(
            @RequestParam(value = "nickname", required = true) String nickname,
            @RequestParam(value = "id_asta", required = true) Integer idAsta,
            @RequestParam(value = "offerta", required = true) Float offerta) {

        int statusCode = 200;
        Boolean status = serviceasta.inviaOffertaInversa(nickname, idAsta, offerta);
        if (Boolean.FALSE.equals(status)) {
            statusCode = 400;
        }

        return ResponseEntity.status(statusCode).body( Map.of("status",status));

    }

    @SuppressWarnings("null")
    @Override
    @GetMapping("/img_inversa/{filename}")
    public ResponseEntity<byte[]> ottieniImmagineAsta(@PathVariable String filename) {
       
       try {
        // Load the image from the file system
        Resource imgFile = new ClassPathResource("img/" + filename);

        // Create the HTTP response
        byte[] bytes = StreamUtils.copyToByteArray(imgFile.getInputStream());
        return ResponseEntity
                .ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(bytes);
    } catch (Exception e) {
      
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }
    }

}
