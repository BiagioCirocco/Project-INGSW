package com.controller.interfaces;

public interface ControllerUtente <T>{
    public T richiediModificaProfilo(String nickname,
            String email,
            String password,
            String areageografica,
            String biografia,
            String linklinkedin,
            String linkfacebook,
            String linkinstagram,
            String linktwitter);

    public T richiediProfilo(String nickname);

    public T richiediProprioProfilo(String nickname);

}
