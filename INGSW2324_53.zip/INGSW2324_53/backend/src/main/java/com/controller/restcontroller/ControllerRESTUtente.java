package com.controller.restcontroller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.controller.interfaces.ControllerUtente;
import com.service.ServiceUtente;

@RestController
public class ControllerRESTUtente implements ControllerUtente<Object>{
  
  
  private ServiceUtente serviceutente = new ServiceUtente();

  @PostMapping("/modifica_profilo")
  @Override
  public  ResponseEntity<Map<String, Object>> richiediModificaProfilo(
      @RequestParam(value = "nickname", required = true) String nickname,
      @RequestParam(value = "email", required = true) String email,
      @RequestParam(value = "password", required = true) String password,
      @RequestParam(value = "area_geografica", required = true) String areageografica,
      @RequestParam(value = "biografia", required = true) String biografia,
      @RequestParam(value = "link_linkedin", required = true) String linklinkedin,
      @RequestParam(value = "link_facebook", required = true) String linkfacebook,
      @RequestParam(value = "link_instagram", required = true) String linkinstagram,
      @RequestParam(value = "link_twitter", required = true) String linktwitter) {
        
        int statusCode = 200;
        Boolean status = serviceutente.modificaProfilo(nickname, email, password, areageografica, biografia, linklinkedin, linkfacebook,
        linkinstagram, linktwitter);
        if (Boolean.FALSE.equals(status)) {
          statusCode = 400;
        }

        return ResponseEntity.status(statusCode).body(Map.of("status", status));
    
  }

  @GetMapping("/profilo/{nickname}")
  @Override
  public Map<String, Object> richiediProfilo(@PathVariable String nickname) {
    return Map.of("status", serviceutente.visualizzaProfilo(nickname));
  }

  @GetMapping("/mio_profilo/{nickname}")
  @Override
  public Map<String, Object> richiediProprioProfilo(@PathVariable String nickname) {
    return Map.of("status",serviceutente.visualizzaProprioProfilo(nickname));
  }
}
