package com.controller.interfaces;

import java.util.Date;

public interface ControllerRegistrazione<T2> {
   public T2 richiediRegistrazione(
            String email,
            String password,
            String areageografica,
            String nickname,
            Date dataDiNascita,
            String sesso,
            String biografia);
}
