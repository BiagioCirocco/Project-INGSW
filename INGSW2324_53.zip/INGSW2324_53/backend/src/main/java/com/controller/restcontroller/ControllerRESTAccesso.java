package com.controller.restcontroller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.controller.interfaces.ControllerAccesso;
import com.service.ServiceAccesso;

@RestController
public class ControllerRESTAccesso implements ControllerAccesso<Object>{

  private ServiceAccesso saccessi = new ServiceAccesso();

  @PostMapping("/accedi")
  @Override
  public ResponseEntity<Map<String, Boolean>> richiediAccesso(
      @RequestParam(value = "nickname", required = true) String nickname,
      @RequestParam(value = "password", required = true) String password) {

    int statusCode = 200;
    Boolean status = saccessi.effettuaAccesso(nickname, password);
    if (Boolean.FALSE.equals(status)) {
      statusCode = 400;
    }

    return ResponseEntity.status(statusCode).body(Map.of("status", status));

  }
}
