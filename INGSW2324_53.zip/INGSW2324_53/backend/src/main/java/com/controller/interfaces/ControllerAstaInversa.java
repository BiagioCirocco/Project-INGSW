package com.controller.interfaces;

public interface ControllerAstaInversa<T2> extends ControllerAsta<T2> {

    public T2 inviaOfferta(
            String nickname,
            Integer idAsta,
            Float offerta);
}
