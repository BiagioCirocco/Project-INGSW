package com.controller.interfaces;

public interface ControllerAstaSilenziosa<T2> extends ControllerAsta<T2> {

    public T2 inviaOfferta(
            String nickname,
            Integer idAsta,
            Float offerta);

    public T2 accettaOfferta(Integer idOfferta);
}
