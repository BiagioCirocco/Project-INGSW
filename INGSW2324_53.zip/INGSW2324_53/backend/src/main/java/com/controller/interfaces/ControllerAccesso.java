package com.controller.interfaces;

public interface ControllerAccesso<T> {
 public T richiediAccesso(String email,String password);
}
