
package com.factory;

import com.dao.interfaces.AstaInversaDAO;
import com.dao.interfaces.AstaSilenziosaDAO;
import com.dao.interfaces.UtenteDAO;
import com.dao.mysql.MysqlAstaInversaDAO;
import com.dao.mysql.MysqlAstaSilenziosaDAO;
import com.dao.mysql.MysqlUtenteDAO;

public class DAOFactory {

    private static DAOFactory instance=null;
    public static final int MYSQL = 1;
    private static final String ERROR = "DB non valido";

    public static synchronized DAOFactory getInstance() {
        if (instance == null) {
            instance = new DAOFactory();
        }
        return instance;
    }


    public UtenteDAO getUtenteDAO(int whichFactory) {
        switch (whichFactory) {
            case MYSQL:
                return MysqlUtenteDAO.getInstance();
            default:
                throw new IllegalArgumentException(ERROR);
        }
    }

    public AstaInversaDAO getAstaInversaDAO(int whichFactory) {
        switch (whichFactory) {
            case MYSQL:
                return MysqlAstaInversaDAO.getInstance();
            default:
            throw new IllegalArgumentException(ERROR);
        }
    }

    public AstaSilenziosaDAO getAstaSilenziosaDAO(int whichFactory) {
        switch (whichFactory) {
            case MYSQL:
                return MysqlAstaSilenziosaDAO.getInstance();
            default:
            throw new IllegalArgumentException(ERROR);
        }

    }

}
