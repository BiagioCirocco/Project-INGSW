package com.db.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;

public class MysqlConnection {

    private static Connection instance = null;
    private static final  String ADDRESS = "darkumbo-mariadb-1";
    private static final  String PORT = "3306";
    private static final  String DATABASE = "dieti2";
    private static final  String USER = "root";
    private static final  String PASSWORD = "dieti";

    private MysqlConnection() {
    }

    public static synchronized Connection getInstance() {
        if (instance == null) {
            try {
                instance = DriverManager
                        .getConnection("jdbc:mariadb://" + ADDRESS + ":" + PORT + "/" + DATABASE + "?user="
                                + USER + "&password=" + PASSWORD);
            } catch (SQLException e) {
             
               Logger.getLogger("global").info(e.toString());
            }
        }
        return instance;
    }

}
