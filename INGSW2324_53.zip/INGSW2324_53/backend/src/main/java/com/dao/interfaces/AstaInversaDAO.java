package com.dao.interfaces;

import com.entity.AstaInversa;

public interface AstaInversaDAO extends AstaDAO {

    public Boolean inviaOffertaInversa(AstaInversa asta);


}
