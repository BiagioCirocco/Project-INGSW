package com.dao.interfaces;

import com.entity.AstaSilenziosa;
import com.entity.OffertaAstaSilenziosa;

public interface AstaSilenziosaDAO extends AstaDAO {

    public Boolean inviaOffertaSilenziosa(AstaSilenziosa asta);

    public Boolean accettaOffertaSilenziosa(OffertaAstaSilenziosa offertaAstaSilenziosa);

    

}
