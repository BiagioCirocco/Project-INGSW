package com.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.entity.AstaSilenziosa;
import com.entity.OffertaAstaSilenziosa;
import com.entity.Utente;
import com.entity.abstracts.Asta;

import com.dao.interfaces.AstaSilenziosaDAO;
import com.db.mysql.MysqlConnection;

public class MysqlAstaSilenziosaDAO implements AstaSilenziosaDAO {

    private static MysqlAstaSilenziosaDAO instance = null;
    private Connection connection = MysqlConnection.getInstance();

    public static synchronized MysqlAstaSilenziosaDAO getInstance() {
        if (instance == null) {
            instance = new MysqlAstaSilenziosaDAO();
        }
        return instance;
    }

    @Override
    public List<Asta> ottieniAste() {

        List<Asta> result = new ArrayList<>();

        String sql = "SELECT utente,id,titolo,categoria,immagine,scadenza FROM astasilenziosa WHERE scadenza > NOW() AND id NOT IN (SELECT asta FROM offertasilenziosa WHERE Accettata = 'si')";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {

            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                AstaSilenziosa astasilenziosa = new AstaSilenziosa();
                astasilenziosa.setTitolo(rowAffected.getString("titolo"));
                astasilenziosa.setImmagine(rowAffected.getString("immagine"));
                astasilenziosa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astasilenziosa.setCategoria(rowAffected.getString("categoria"));
                astasilenziosa.setId(rowAffected.getInt("id"));
                astasilenziosa.setUtente(new Utente(rowAffected.getString("utente")));
                result.add(astasilenziosa);
            }

        } catch (SQLException e) {
             Logger.getLogger("global").info(e.toString());
        }

        return result;

    }

    @Override
    public Asta ottieniInformazioniAsta(Asta asta) {

        AstaSilenziosa astaSilenziosa = (AstaSilenziosa) asta;

        String sql = "SELECT titolo, immagine, descrizione, scadenza, categoria, utente FROM astasilenziosa WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, asta.getId());

            ResultSet rowAffected = pstmt.executeQuery();
            if (rowAffected.next()) {

                astaSilenziosa.setTitolo(rowAffected.getString("titolo"));
                astaSilenziosa.setImmagine(rowAffected.getString("immagine"));
                astaSilenziosa.setDescrizione(rowAffected.getString("descrizione"));
                astaSilenziosa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astaSilenziosa.setCategoria(rowAffected.getString("categoria"));

                astaSilenziosa.setUtente(new Utente(rowAffected.getString("utente")));

            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return astaSilenziosa;
    }

    @Override
    public Asta ottieniInformazioniMiaAsta(Asta asta) {

        AstaSilenziosa astaSilenziosa = (AstaSilenziosa) asta;

        String sql = "SELECT titolo, immagine, descrizione, scadenza, categoria, utente FROM astasilenziosa WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, asta.getId());
            ResultSet rowAffected = pstmt.executeQuery();
            if (rowAffected.next()) {

                astaSilenziosa.setTitolo(rowAffected.getString("titolo"));
                astaSilenziosa.setImmagine(rowAffected.getString("immagine"));
                astaSilenziosa.setDescrizione(rowAffected.getString("descrizione"));
                astaSilenziosa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astaSilenziosa.setCategoria(rowAffected.getString("categoria"));

                String sql2 = "SELECT id,valore, utente FROM offertasilenziosa WHERE asta = ? ORDER BY valore DESC";
                try (PreparedStatement pstmt2 = connection.prepareStatement(sql2)) {
                    pstmt2.setInt(1, asta.getId());
                    ResultSet rowAffected2 = pstmt2.executeQuery();
                    while (rowAffected2.next()) {
                        astaSilenziosa.getOfferta().add(new OffertaAstaSilenziosa(rowAffected2.getFloat("valore"),
                                new Utente(rowAffected2.getString("utente")), rowAffected2.getInt("id")));

                    }

                    astaSilenziosa.setUtente(new Utente(rowAffected.getString("utente")));
                }
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }
        return astaSilenziosa;

    }

    @Override
    public List<Asta> ottieniAsteVinte(Utente utente) {

        String sql = "SELECT offertasilenziosa.id, offertasilenziosa.valore, astasilenziosa.* FROM offertasilenziosa INNER JOIN astasilenziosa ON offertasilenziosa.asta = astasilenziosa.id WHERE offertasilenziosa.utente = ? AND offertasilenziosa.Accettata = 'si'";
        List<Asta> result = new ArrayList<>();
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {

            pstmt.setString(1, utente.getNickname());

            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {

                AstaSilenziosa astaSilenziosa = new AstaSilenziosa();
                astaSilenziosa.setId(rowAffected.getInt("astasilenziosa.id"));
                astaSilenziosa.setTitolo(rowAffected.getString("astasilenziosa.titolo"));
                astaSilenziosa.setImmagine(rowAffected.getString("astasilenziosa.immagine"));

                astaSilenziosa.setCategoria(rowAffected.getString("astasilenziosa.categoria"));
                result.add(astaSilenziosa);
                astaSilenziosa.setUtente(new Utente(rowAffected.getString("astasilenziosa.utente")));
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public Integer creaNuovaAstaDaUtente(Utente utente) {
        Integer result = null;
        String sql = "INSERT INTO astasilenziosa (titolo, descrizione, scadenza, categoria, utente) VALUES (?, ?, ?, ?, ?)";

        AstaSilenziosa astasilenziosa = (AstaSilenziosa) utente.getAsta().get(0);

        try (PreparedStatement pstmt = connection.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, astasilenziosa.getTitolo());
            pstmt.setString(2, astasilenziosa.getDescrizione());
            pstmt.setTimestamp(3, astasilenziosa.getScadenza());
            pstmt.setString(4, astasilenziosa.getCategoria());
            pstmt.setString(5, utente.getNickname());

            int rowAffected = pstmt.executeUpdate();
            if (rowAffected == 1) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    result = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public List<String> ottieniCategorie() {
        List<String> result = new ArrayList<>();

        String sql = "SELECT Denominazione FROM categoria";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {

            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                result.add(rowAffected.getString("Denominazione"));
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public Boolean inviaOffertaSilenziosa(AstaSilenziosa asta) {

        Boolean result = false;
        String sql = """
            INSERT INTO offertasilenziosa (valore, utente, asta)
            SELECT ?, ?, ?
            FROM dual 
            WHERE NOT EXISTS
            (SELECT 1 
            FROM offertasilenziosa
            WHERE asta = ? AND Accettata = 'si')""";
                    
                    
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setFloat(1, asta.getOfferta().get(0).getValore());
            pstmt.setString(2, asta.getOfferta().get(0).getUtente().getNickname());
            pstmt.setInt(3, asta.getId());
            pstmt.setInt(4, asta.getId());
            int rowAffected = pstmt.executeUpdate();
            if (rowAffected == 1) {
                result = true;
            }
        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }
        return result;
    }

    @Override
    public Boolean accettaOffertaSilenziosa(OffertaAstaSilenziosa offerta) {

        Boolean result = false;
        String sql = """
            UPDATE offertasilenziosa 
                SET accettata = 'si' 
                WHERE id = ? AND asta NOT IN 
                (SELECT asta FROM offertasilenziosa WHERE Accettata = 'si')""";
            
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, offerta.getIdOfferta());
            int rowAffected = pstmt.executeUpdate();
            if (rowAffected == 1) {
                result = true;
            }
        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }
        return result;
    }

    @Override
    public List<Asta> ottieniAsteCategorie(String categoria) {

        List<Asta> result = new ArrayList<>();
        String sql = """
            SELECT id,titolo,categoria,immagine,scadenza,utente 
            FROM astasilenziosa 
            WHERE categoria = ? AND scadenza > NOW() AND id NOT IN 
            (SELECT asta FROM offertasilenziosa WHERE Accettata = 'si')""";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, categoria);
            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                AstaSilenziosa astasilenziosa = new AstaSilenziosa();
                astasilenziosa.setTitolo(rowAffected.getString("titolo"));
                astasilenziosa.setImmagine(rowAffected.getString("immagine"));
                astasilenziosa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astasilenziosa.setCategoria(rowAffected.getString("categoria"));
                astasilenziosa.setId(rowAffected.getInt("id"));
                astasilenziosa.setUtente(new Utente(rowAffected.getString("utente")));
                result.add(astasilenziosa);
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;

    }

    @Override
    public Integer creaNuovaAstaConImmagine(Utente utente) {
        Integer result = null;
        String sql = "INSERT INTO astasilenziosa (titolo, immagine, descrizione, scadenza, categoria, utente) VALUES (?, ?, ?, ?, ?, ?)";

        AstaSilenziosa astasilenziosa = (AstaSilenziosa) utente.getAsta().get(0);

        try (PreparedStatement pstmt = connection.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, astasilenziosa.getTitolo());
            pstmt.setString(2, astasilenziosa.getImmagine());
            pstmt.setString(3, astasilenziosa.getDescrizione());
            pstmt.setTimestamp(4, astasilenziosa.getScadenza());
            pstmt.setString(5, astasilenziosa.getCategoria());
            pstmt.setString(6, utente.getNickname());

            int rowAffected = pstmt.executeUpdate();
            if (rowAffected == 1) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    result = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public List<Asta> ottieniAsteCategoriaTitolo(String categoria, String titolo) {
        List<Asta> result = new ArrayList<>();
        String sql = """
            SELECT id,titolo,categoria,immagine,scadenza,utente 
            FROM astasilenziosa 
            WHERE categoria = ? AND scadenza > NOW() AND titolo LIKE ? AND id NOT IN 
            (SELECT asta FROM offertasilenziosa WHERE Accettata = 'si')""";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, categoria);
            pstmt.setString(2, "%" + titolo + "%");
            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                AstaSilenziosa astasilenziosa = new AstaSilenziosa();
                astasilenziosa.setTitolo(rowAffected.getString("titolo"));
                astasilenziosa.setImmagine(rowAffected.getString("immagine"));
                astasilenziosa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astasilenziosa.setCategoria(rowAffected.getString("categoria"));
                astasilenziosa.setId(rowAffected.getInt("id"));
                astasilenziosa.setUtente(new Utente(rowAffected.getString("utente")));
                result.add(astasilenziosa);
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public List<Asta> ottieniAsteTitolo(String titolo) {
        List<Asta> result = new ArrayList<>();
        String sql = """
                SELECT id,titolo,categoria,immagine,scadenza,utente 
                FROM astasilenziosa 
                WHERE scadenza > NOW() AND titolo LIKE ? AND id NOT IN 
                (SELECT asta FROM offertasilenziosa
                WHERE Accettata = 'si')""";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {

            pstmt.setString(1, "%" + titolo + "%");
            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                AstaSilenziosa astasilenziosa = new AstaSilenziosa();
                astasilenziosa.setTitolo(rowAffected.getString("titolo"));
                astasilenziosa.setImmagine(rowAffected.getString("immagine"));
                astasilenziosa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astasilenziosa.setCategoria(rowAffected.getString("categoria"));
                astasilenziosa.setId(rowAffected.getInt("id"));
                astasilenziosa.setUtente(new Utente(rowAffected.getString("utente")));
                result.add(astasilenziosa);
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

}
