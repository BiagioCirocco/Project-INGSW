package com.dao.interfaces;

import com.entity.Utente;

public interface UtenteDAO {

    public Boolean registraUtente(Utente utente);

    public Boolean accedi(Utente utente);

    public Boolean apportaModificaProfilo(Utente utente);

    public Utente ottieniProfilo(Utente utente);

    public Utente ottieniProprioProfilo(Utente utente);
}
