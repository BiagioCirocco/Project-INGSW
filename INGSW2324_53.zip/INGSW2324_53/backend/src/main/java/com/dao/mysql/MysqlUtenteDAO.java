package com.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import com.dao.interfaces.UtenteDAO;
import com.db.mysql.MysqlConnection;
import com.entity.AstaInversa;
import com.entity.AstaSilenziosa;
import com.entity.Utente;


public class MysqlUtenteDAO implements UtenteDAO {

    private static MysqlUtenteDAO instance = null;
    private Connection connection = MysqlConnection.getInstance();

    private MysqlUtenteDAO() {
       
    }

    public static synchronized MysqlUtenteDAO getInstance() {
        if (instance == null) {
            instance = new MysqlUtenteDAO();
        }
        return instance;
    }

    @Override
    public Boolean registraUtente(Utente utente) {

        Boolean status = true;
        String sql = "INSERT INTO utente (Email, Nickname, Password, DataDiNascita, Sesso, Biografia, AreaGeografica) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {

           
            pst.setString(1, utente.getEmail());
            pst.setString(2, utente.getNickname());
            pst.setString(3, utente.getPassword());
            pst.setDate(4, new java.sql.Date(utente.getDataDiNascita().getTime()));
            pst.setString(5, utente.getSesso());
            pst.setString(6, utente.getBiografia());
            pst.setString(7, utente.getAreaGeografica());

            pst.executeUpdate();

        } catch (SQLException ex) {
            status = false;
        
        }
        return status;
    }

    @Override
    public Boolean accedi(Utente utente) {
        String sql = "SELECT * FROM utente WHERE Nickname = ? AND Password = ?";
        Boolean result = false;

        try (PreparedStatement pst = connection.prepareStatement(sql)) {

            pst.setString(1, utente.getNickname());
            pst.setString(2, utente.getPassword());

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                result = true;
            }

        } catch (SQLException ex) {
            Logger.getLogger("global").info(ex.toString());
  
        
        }
        return result;
    }

    @Override
    public Boolean apportaModificaProfilo(Utente utente) {

        String sql = "UPDATE utente SET Biografia = ?, AreaGeografica = ?, Password = ?,LinkLinkedin = ?,LinkFacebook = ? ,LinkInstagram = ? ,LinkTwitter = ?,Email = ? WHERE Nickname = ?";
        Boolean result = false;

        try (PreparedStatement pst = connection.prepareStatement(sql)) {

            pst.setString(1, utente.getBiografia());
            pst.setString(2, utente.getAreaGeografica());
            pst.setString(3, utente.getPassword());
            pst.setString(4, utente.getLinkLinkedin());
            pst.setString(5, utente.getLinkFacebook());
            pst.setString(6, utente.getLinkInstagram());
            pst.setString(7, utente.getLinkTwitter());
            pst.setString(8, utente.getEmail());
            pst.setString(9, utente.getNickname());

            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                result = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger("global").info(ex.toString());
        }
        return result;
    }

    @Override
    public Utente ottieniProfilo(Utente utente) {

        String sql = "SELECT Nickname, AreaGeografica, IscrittoDal, Sesso, Biografia,LinkLinkedin,LinkInstagram,LinkFacebook,LinkTwitter  FROM utente WHERE Nickname = ?";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {

            pst.setString(1, utente.getNickname());

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                utente.setNickname(rs.getString("Nickname"));
                utente.setAreaGeografica(rs.getString("AreaGeografica"));
                utente.setIscrittoDal(rs.getDate("IscrittoDal"));
                utente.setSesso(rs.getString("Sesso"));
                utente.setBiografia(rs.getString("Biografia"));
                utente.setLinkLinkedin(rs.getString("LinkLinkedin"));
                utente.setLinkInstagram(rs.getString("LinkInstagram"));
                utente.setLinkFacebook(rs.getString("LinkFacebook"));
                utente.setLinkTwitter(rs.getString("LinkTwitter"));
                return utente;
            }

        } catch (SQLException ex) {
            Logger.getLogger("global").info(ex.toString());
        }
        return null;

    }

    @Override
    public Utente ottieniProprioProfilo(Utente utente) {

        String sql = "SELECT Nickname, AreaGeografica, IscrittoDal, Sesso, Biografia,LinkLinkedin,LinkInstagram,LinkFacebook,LinkTwitter,Email,DataDiNascita,Password  FROM utente WHERE Nickname = ?";
        String sqlastainversa = "SELECT id,Titolo, Immagine, Categoria,Scadenza,prezzodipartenza FROM astainversa WHERE utente = ?";
        String sqlastasilenziosa = "SELECT id,Titolo, Immagine, Categoria,Scadenza FROM astasilenziosa WHERE utente = ?";

        try (PreparedStatement pst = connection.prepareStatement(sql);
                PreparedStatement pst2 = connection.prepareStatement(sqlastainversa);
                PreparedStatement pst3 = connection.prepareStatement(sqlastasilenziosa)) {

            pst.setString(1, utente.getNickname());
            pst2.setString(1, utente.getNickname());
            pst3.setString(1, utente.getNickname());

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                utente.setNickname(rs.getString("Nickname"));
                utente.setAreaGeografica(rs.getString("AreaGeografica"));
                utente.setIscrittoDal(rs.getDate("IscrittoDal"));
                utente.setSesso(rs.getString("Sesso"));
                utente.setBiografia(rs.getString("Biografia"));
                utente.setLinkLinkedin(rs.getString("LinkLinkedin"));
                utente.setLinkInstagram(rs.getString("LinkInstagram"));
                utente.setLinkFacebook(rs.getString("LinkFacebook"));
                utente.setLinkTwitter(rs.getString("LinkTwitter"));
                utente.setEmail(rs.getString("Email"));
                utente.setDataDiNascita(rs.getDate("DataDiNascita"));
                utente.setPassword(rs.getString("Password"));

                ResultSet rs2 = pst2.executeQuery();
                while (rs2.next()) {
                    AstaInversa asta = new AstaInversa(rs2.getString("Titolo"), rs2.getString("Immagine"),
                            rs2.getString("Categoria"), rs2.getInt("id"));
                    asta.setScadenza(rs2.getTimestamp("Scadenza"));
                    asta.setPrezzoDiPartenza(rs2.getFloat("prezzodipartenza"));

                    utente.getAsta().add(asta);

                }

                ResultSet rs3 = pst3.executeQuery();
                while (rs3.next()) {

                    AstaSilenziosa asta = new AstaSilenziosa(rs3.getString("Titolo"), rs3.getString("Immagine"),
                            rs3.getString("Categoria"), rs3.getInt("id"));
                    asta.setScadenza(rs3.getTimestamp("Scadenza"));

                    utente.getAsta().add(asta);

                }
                return utente;
            }

        } catch (SQLException ex) {
            Logger.getLogger("global").info(ex.toString());
        }
        return null;
    }

}
