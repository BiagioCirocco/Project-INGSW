package com.dao.interfaces;

import java.util.List;

import com.entity.Utente;
import com.entity.abstracts.Asta;

public interface AstaDAO {


    public List<Asta> ottieniAste();
    public Asta ottieniInformazioniAsta(Asta asta);
    public Asta ottieniInformazioniMiaAsta(Asta asta);
    public List<Asta> ottieniAsteVinte(Utente utente);
    public Integer creaNuovaAstaDaUtente(Utente utente);
    public Integer creaNuovaAstaConImmagine(Utente utente);
    public List<String> ottieniCategorie();
    public List<Asta> ottieniAsteCategorie(String categoria);
    public List<Asta> ottieniAsteTitolo(String titolo);
    public List<Asta> ottieniAsteCategoriaTitolo(String categoria,String titolo);
}



