package com.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.dao.interfaces.AstaInversaDAO;
import com.db.mysql.MysqlConnection;
import com.entity.AstaInversa;
import com.entity.Utente;
import com.entity.abstracts.Asta;

public class MysqlAstaInversaDAO implements AstaInversaDAO {

    private static MysqlAstaInversaDAO instance = null;
    private Connection connection =MysqlConnection.getInstance();

    private MysqlAstaInversaDAO() {
       
    }

    public static synchronized MysqlAstaInversaDAO getInstance() {
        if (instance == null) {
            instance = new MysqlAstaInversaDAO();
        }
        return instance;
    }

    @Override
    public List<Asta> ottieniAste() {
        List<Asta> result = new ArrayList<>();

        String sql = "SELECT utente,id,titolo,categoria,immagine,scadenza,COALESCE((SELECT CASE WHEN MIN(valore) < prezzodipartenza THEN MIN(valore) ELSE NULL END FROM offertainversa WHERE asta = astainversa.id), prezzodipartenza) AS prezzodipartenza FROM astainversa WHERE scadenza > NOW()";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {

            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                AstaInversa astainversa = new AstaInversa();
                astainversa.setTitolo(rowAffected.getString("titolo"));
                astainversa.setImmagine(rowAffected.getString("immagine"));
                astainversa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astainversa.setPrezzoDiPartenza(rowAffected.getFloat("prezzodipartenza"));
                astainversa.setCategoria(rowAffected.getString("categoria"));
                astainversa.setUtente(new Utente(rowAffected.getString("utente")));
                astainversa.setId(rowAffected.getInt("id"));
                result.add(astainversa);
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public Asta ottieniInformazioniAsta(Asta asta) {

        AstaInversa astainversa = (AstaInversa) asta;
        String sql = "SELECT titolo, immagine, descrizione, scadenza, COALESCE((SELECT CASE WHEN MIN(valore) < prezzodipartenza THEN MIN(valore) ELSE NULL END FROM offertainversa WHERE asta = ?), prezzodipartenza) AS prezzo, categoria, utente FROM astainversa WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, asta.getId());
            pstmt.setInt(2, asta.getId());
            ResultSet rowAffected = pstmt.executeQuery();
            if (rowAffected.next()) {

                astainversa.setTitolo(rowAffected.getString("titolo"));
                astainversa.setImmagine(rowAffected.getString("immagine"));
                astainversa.setDescrizione(rowAffected.getString("descrizione"));
                astainversa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astainversa.setPrezzoDiPartenza(rowAffected.getFloat("prezzo"));
                astainversa.setCategoria(rowAffected.getString("categoria"));
                astainversa.setUtente(new Utente(rowAffected.getString("utente")));

            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return astainversa;
    }

    @Override
    public Asta ottieniInformazioniMiaAsta(Asta asta) {
        AstaInversa astainversa = (AstaInversa) asta;

        String sql = "SELECT titolo, immagine, descrizione, scadenza, COALESCE((SELECT CASE WHEN MIN(valore) < prezzodipartenza THEN MIN(valore) ELSE NULL END FROM offertainversa WHERE id = ?), prezzodipartenza) AS prezzo, categoria, utente FROM astainversa WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, asta.getId());
            pstmt.setInt(2, asta.getId());
            ResultSet rowAffected = pstmt.executeQuery();
            if (rowAffected.next()) {

                astainversa.setTitolo(rowAffected.getString("titolo"));
                astainversa.setImmagine(rowAffected.getString("immagine"));
                astainversa.setDescrizione(rowAffected.getString("descrizione"));
                astainversa.setScadenza(rowAffected.getTimestamp("scadenza"));
                astainversa.setPrezzoDiPartenza(rowAffected.getFloat("prezzo"));
                astainversa.setCategoria(rowAffected.getString("categoria"));
                astainversa.setUtente(new Utente(rowAffected.getString("utente")));

            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return astainversa;

    }

    @Override
    public List<Asta> ottieniAsteVinte(Utente utente) {

        String sql = "SELECT astainversa.* FROM astainversa WHERE astainversa.id IN (SELECT offertainversa.asta FROM offertainversa WHERE offertainversa.valore = (SELECT MIN(valore) FROM offertainversa WHERE asta = astainversa.id) AND offertainversa.utente = ?) AND astainversa.scadenza < NOW()";
        List<Asta> result = new ArrayList<>();
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, utente.getNickname());
          
            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {

                AstaInversa astainversa = new AstaInversa();
                astainversa.setId(rowAffected.getInt("astainversa.id"));
                astainversa.setTitolo(rowAffected.getString("astainversa.titolo"));
                astainversa.setImmagine(rowAffected.getString("astainversa.immagine"));
               
                astainversa.setCategoria(rowAffected.getString("astainversa.categoria"));
                astainversa.setUtente(new Utente(rowAffected.getString("astainversa.utente")));
                result.add(astainversa);
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;

    }

    @Override
    public Integer creaNuovaAstaDaUtente(Utente utente) {

        Integer result=null;
        String sql = "INSERT INTO astainversa (titolo, descrizione, scadenza, prezzodipartenza, categoria, utente) VALUES (?, ?, ?, ?, ?, ?)";

        AstaInversa astainversa = (AstaInversa) utente.getAsta().get(0);

        try (PreparedStatement pstmt = connection.prepareStatement(sql,  java.sql.Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, astainversa.getTitolo());
            pstmt.setString(2, astainversa.getDescrizione());
            pstmt.setTimestamp(3, astainversa.getScadenza());
            pstmt.setFloat(4, astainversa.getPrezzoDiPartenza());
            pstmt.setString(5, astainversa.getCategoria());
            pstmt.setString(6, utente.getNickname());

            int rowAffected = pstmt.executeUpdate();
            if (rowAffected == 1) {

                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    result = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public List<String> ottieniCategorie() {
        List<String> result = new ArrayList<>();

        String sql = "SELECT Denominazione FROM categoria";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {

            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                result.add(rowAffected.getString("Denominazione"));
            }

        } catch (SQLException e) {
          Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public Boolean inviaOffertaInversa(AstaInversa asta) {

        Boolean result = false;
        String sql = "INSERT INTO offertainversa (valore, utente, asta) VALUES (?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setFloat(1, asta.getOfferta().get(0).getValore());
            pstmt.setString(2, asta.getOfferta().get(0).getUtente().getNickname());
            pstmt.setInt(3, asta.getId());

            int rowAffected = pstmt.executeUpdate();
            if (rowAffected == 1) {
                result = true;
            }
        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }
        return result;
    }

    @Override
    public List<Asta> ottieniAsteCategorie(String categoria) {

        List<Asta> result = new ArrayList<>();
        String sql = "SELECT id,titolo,categoria,immagine,scadenza,COALESCE((SELECT CASE WHEN MIN(valore) < prezzodipartenza THEN MIN(valore) ELSE NULL END FROM offertainversa WHERE asta = astainversa.id), prezzodipartenza) AS prezzodipartenza,utente FROM astainversa WHERE categoria = ? AND scadenza > NOW()";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, categoria);
            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                AstaInversa astainversa = new AstaInversa();
                astainversa.setTitolo(rowAffected.getString("titolo"));
                astainversa.setImmagine(rowAffected.getString("immagine"));
                astainversa.setScadenza(rowAffected.getTimestamp("scadenza"));

            
                astainversa.setPrezzoDiPartenza(rowAffected.getFloat("prezzodipartenza"));
                astainversa.setCategoria(rowAffected.getString("categoria"));
                astainversa.setId(rowAffected.getInt("id"));
                astainversa.setUtente(new Utente(rowAffected.getString("utente")));
                result.add(astainversa);
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public Integer creaNuovaAstaConImmagine(Utente utente) {
        Integer result = null;
        String sql = "INSERT INTO astainversa (titolo, immagine, descrizione, scadenza, prezzodipartenza, categoria, utente) VALUES (?, ?, ?, ?, ?, ?, ?)";

        AstaInversa astainversa = (AstaInversa) utente.getAsta().get(0);

        try (PreparedStatement pstmt = connection.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, astainversa.getTitolo());
            pstmt.setString(2, astainversa.getImmagine());
            pstmt.setString(3, astainversa.getDescrizione());
            pstmt.setTimestamp(4, astainversa.getScadenza());
            pstmt.setFloat(5, astainversa.getPrezzoDiPartenza());
            pstmt.setString(6, astainversa.getCategoria());
            pstmt.setString(7, utente.getNickname());

            int rowAffected = pstmt.executeUpdate();
            if (rowAffected == 1) {

                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    result = rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public List<Asta> ottieniAsteCategoriaTitolo(String categoria, String titolo) {
        List<Asta> result = new ArrayList<>();
        String sql = "SELECT id,titolo,categoria,immagine,scadenza,COALESCE((SELECT CASE WHEN MIN(valore) < prezzodipartenza THEN MIN(valore) ELSE NULL END FROM offertainversa WHERE asta = astainversa.id), prezzodipartenza) AS prezzodipartenza,utente FROM astainversa WHERE categoria = ? AND scadenza > NOW() AND titolo LIKE ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, categoria);
            pstmt.setString(2, "%" + titolo + "%");
            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                AstaInversa astainversa = new AstaInversa();
                astainversa.setTitolo(rowAffected.getString("titolo"));
                astainversa.setImmagine(rowAffected.getString("immagine"));
                astainversa.setScadenza(rowAffected.getTimestamp("scadenza"));

             
                astainversa.setPrezzoDiPartenza(rowAffected.getFloat("prezzodipartenza"));
                astainversa.setCategoria(rowAffected.getString("categoria"));
                astainversa.setId(rowAffected.getInt("id"));
                astainversa.setUtente(new Utente(rowAffected.getString("utente")));
                result.add(astainversa);
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

    @Override
    public List<Asta> ottieniAsteTitolo(String titolo) {
        List<Asta> result = new ArrayList<>();
        String sql = "SELECT id,titolo,categoria,immagine,scadenza,COALESCE((SELECT CASE WHEN MIN(valore) < prezzodipartenza THEN MIN(valore) ELSE NULL END FROM offertainversa WHERE asta = astainversa.id), prezzodipartenza) AS prezzodipartenza,utente FROM astainversa WHERE scadenza > NOW() AND titolo LIKE ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, "%" + titolo + "%");
            ResultSet rowAffected = pstmt.executeQuery();
            while (rowAffected.next()) {
                AstaInversa astainversa = new AstaInversa();
                astainversa.setTitolo(rowAffected.getString("titolo"));
                astainversa.setImmagine(rowAffected.getString("immagine"));
                astainversa.setScadenza(rowAffected.getTimestamp("scadenza"));

                
                astainversa.setPrezzoDiPartenza(rowAffected.getFloat("prezzodipartenza"));
                astainversa.setCategoria(rowAffected.getString("categoria"));
                astainversa.setId(rowAffected.getInt("id"));
                astainversa.setUtente(new Utente(rowAffected.getString("utente")));
                result.add(astainversa);
            }

        } catch (SQLException e) {
            Logger.getLogger("global").info(e.toString());
        }

        return result;
    }

}
