package com.service.interfaces;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.logging.Logger;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.PathVariable;

import com.entity.abstracts.Asta;


public interface ServiceAsta {
    public Integer creaAsta(Map<String, String> params);

    public Asta informazioniAsta(Integer id);

    public Asta informazioniMiaAsta(Integer id);

    public List<String> ottieniCategorie();

    public List<Asta> ottieniAste(String categoria, String titolo);

    public List<Asta> ottieniAsteVinte(@PathVariable String nickname);

     private String imgBBUpload(String base64Image) throws IOException{

        final String API = "https://api.imgbb.com/1/upload?key=";
        final String key = "80746f700fdd5e0a9d27d3fcfde128de";
        StringBuilder jsonResponse = new StringBuilder();
        String str=null;
        URL url = new URL(API + key);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        String boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW";
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

        StringBuilder postData = new StringBuilder();
        postData.append("--" + boundary + "\r\n");
        postData.append("Content-Disposition: form-data; name=\"image\"\r\n\r\n");
        postData.append(base64Image + "\r\n");
        postData.append("--" + boundary + "--\r\n");

        byte[] postDataBytes = postData.toString().getBytes(StandardCharsets.UTF_8);
        conn.getOutputStream().write(postDataBytes);

        BufferedReader in;
        if (conn.getResponseCode() >= 400) {
           
            throw new  IOException();
        } else {
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
         
            while ((inputLine = in.readLine()) != null) {
                jsonResponse.append(inputLine);
            }
            str = jsonResponse.toString();
        }

        in.close();

        conn.disconnect();
        return str;

    }

    public default String postImage(String base64Image) {

        try {
            return  parseResponseimgBB(imgBBUpload(base64Image));
        } catch (Exception e) {
            return parseReponseCustom(customUpload(base64Image));
        }

    }

     private String customUpload(String base64Image){
         try {
     
        byte[] imageBytes = Base64.getDecoder().decode(base64Image);

       
        Files.createDirectories(Paths.get("img"));

        
        String filename = "img/" + System.currentTimeMillis() + ".jpg";

        
        Files.write(Paths.get(filename), imageBytes, StandardOpenOption.CREATE);

        return filename;
    } catch (Exception e) {
        Logger.getLogger("global").info(e.toString());
        return null;
    }

     }

     private String parseReponseCustom(String filename){
        
        return "http://34.125.242.219/img/"+filename;

     }

    private String parseResponseimgBB(String httpResponse) {
       
        JSONObject jsonObject = new JSONObject(httpResponse);
        JSONObject dataObject = jsonObject.getJSONObject("data");
        return dataObject.getString("url");
       
    }

    public default Timestamp formattaScadenza(String scadenza) {

        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            format.setTimeZone(TimeZone.getTimeZone("Europe/Rome"));
            java.util.Date parsed = format.parse(scadenza);
            return new java.sql.Timestamp(parsed.getTime());
        } catch (ParseException e) {
            Logger.getLogger("global").info(e.toString());
        }
        return null;
    }
}
