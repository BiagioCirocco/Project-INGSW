package com.service;

import java.util.List;
import java.util.Map;

import com.dao.interfaces.AstaSilenziosaDAO;
import com.entity.AstaSilenziosa;
import com.entity.OffertaAstaSilenziosa;
import com.entity.Utente;
import com.entity.abstracts.Asta;
import com.factory.DAOFactory;
import com.service.interfaces.ServiceAsta;

public class ServiceAstaSilenziosa implements ServiceAsta {

    private DAOFactory daofactory = DAOFactory.getInstance();
    private AstaSilenziosaDAO astadao = daofactory.getAstaSilenziosaDAO(DAOFactory.MYSQL);

    public Boolean accettaOffertaSilenziosa(Integer idOfferta) {
        OffertaAstaSilenziosa offertasilenziosa = new OffertaAstaSilenziosa(idOfferta);
        offertasilenziosa.setAccettata();
        return astadao.accettaOffertaSilenziosa(offertasilenziosa);

    }

    public Boolean inviaOffertaSilenziosa(String nickname, Integer idAsta, Float offerta) {

        try {
        AstaSilenziosa asta = new AstaSilenziosa(idAsta);
        OffertaAstaSilenziosa offertastasilenziosa = new OffertaAstaSilenziosa(offerta);
        offertastasilenziosa.setUtente(new Utente(nickname));
        asta.getOfferta().add(offertastasilenziosa);

        return astadao.inviaOffertaSilenziosa(asta);
        } catch (Exception e) {
            return false;
        }
    

    }

    @Override
    public Asta informazioniMiaAsta(Integer idAsta) {

        return astadao.ottieniInformazioniMiaAsta(new AstaSilenziosa(idAsta));
    }

    @Override
    public List<String> ottieniCategorie() {

        return astadao.ottieniCategorie();
    }

    @Override
    public List<Asta> ottieniAsteVinte(String nickname) {

        return astadao.ottieniAsteVinte(new Utente(nickname));
    }

    @Override
    public Integer creaAsta(Map<String, String> params) {
        try{
        Utente utente = new Utente(params.get("nickname"));

        AstaSilenziosa asta = new AstaSilenziosa(
                params.get("titolo"),
                params.get("categoria"), params.get("descrizione"), formattaScadenza(params.get("scadenza")));

        utente.getAsta().add(asta);

        if (!params.get("immagine").equals("")) {
            asta.setImmagine(postImage(params.get("immagine")));
            return astadao.creaNuovaAstaConImmagine(utente);
           
        }
       return astadao.creaNuovaAstaDaUtente(utente);

    } catch (Exception e) {
        return null;
        

    }
}

    

    @Override
    public Asta informazioniAsta(Integer id) {

        return astadao.ottieniInformazioniAsta(new AstaSilenziosa(id));
    }

    public List<Asta> ottieniAste(String categoria, String titolo) {

       if (!titolo.equals("")) {
            if (!categoria.equals("Tutte"))
                return astadao.ottieniAsteCategoriaTitolo(categoria, titolo);
            else
                return astadao.ottieniAsteTitolo(titolo);
        }
        if (!categoria.equals("Tutte")){
         
            return  astadao.ottieniAsteCategorie(categoria);
        }
            
        return astadao.ottieniAste();
    }

}
