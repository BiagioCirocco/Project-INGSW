package com.service;

import com.dao.interfaces.UtenteDAO;
import com.entity.Utente;
import com.factory.DAOFactory;

public class ServiceAccesso {

    private DAOFactory daofactory = DAOFactory.getInstance();
    private UtenteDAO utentedao = daofactory.getUtenteDAO(DAOFactory.MYSQL);


    public Boolean effettuaAccesso(String nickname, String password) {

        return utentedao.accedi(new Utente(nickname, password));


    }
}
