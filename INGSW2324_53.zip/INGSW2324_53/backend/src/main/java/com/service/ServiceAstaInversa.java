package com.service;

import java.util.List;
import java.util.Map;

import com.service.interfaces.ServiceAsta;
import com.dao.interfaces.AstaInversaDAO;
import com.entity.AstaInversa;
import com.entity.OffertaAstaInversa;
import com.entity.Utente;
import com.entity.abstracts.Asta;
import com.factory.DAOFactory;

public class ServiceAstaInversa implements ServiceAsta {

    private DAOFactory daofactory = DAOFactory.getInstance();
    private AstaInversaDAO astadao = daofactory.getAstaInversaDAO(DAOFactory.MYSQL);

    public Boolean inviaOffertaInversa(String nickname, Integer idAsta, Float offerta) {

        AstaInversa astainversa = new AstaInversa(idAsta);
        OffertaAstaInversa offertaAstaInversa = new OffertaAstaInversa(offerta);
        offertaAstaInversa.setUtente(new Utente(nickname));
        astainversa.getOfferta().add(offertaAstaInversa);

        return astadao.inviaOffertaInversa(astainversa);
    }

    @Override
    public Integer creaAsta(Map<String, String> params) {
        try{
        Utente utente = new Utente(params.get("nickname"));

        AstaInversa asta = new AstaInversa(params.get("titolo"),
                params.get("categoria"), formattaScadenza(params.get("scadenza")), params.get("descrizione"),
                Float.parseFloat(params.get("prezzodipartenza")));
        utente.getAsta().add(asta);
        
        if (!params.get("immagine").equals("")) {
            asta.setImmagine(postImage(params.get("immagine")));
            return astadao.creaNuovaAstaConImmagine(utente);
    
        }

       return astadao.creaNuovaAstaDaUtente(utente);
    }catch(Exception e){
        return null;
      
    }
}

    @Override
    public AstaInversa informazioniAsta(Integer idAsta) {

        return (AstaInversa) astadao.ottieniInformazioniAsta(new AstaInversa(idAsta));

    }

    @Override
    public AstaInversa informazioniMiaAsta(Integer idAsta) {

        return (AstaInversa) astadao.ottieniInformazioniMiaAsta(new AstaInversa(idAsta));
    }

    @Override
    public List<String> ottieniCategorie() {

        return astadao.ottieniCategorie();
    }

    @Override
    public List<Asta> ottieniAsteVinte(String nickname) {

        return astadao.ottieniAsteVinte(new Utente(nickname));
    }

    @Override
    public List<Asta> ottieniAste(String categoria, String titolo) {

        try{

        if (!titolo.equals("")){
            if (!categoria.equals("Tutte"))
                return astadao.ottieniAsteCategoriaTitolo(categoria, titolo);
            else
                return astadao.ottieniAsteTitolo(titolo);
        }
        if (!categoria.equals("Tutte")) {
         
            return astadao.ottieniAsteCategorie(categoria);
        }

        return astadao.ottieniAste();
    }catch(Exception e){
        return null;
    }
    }

}
