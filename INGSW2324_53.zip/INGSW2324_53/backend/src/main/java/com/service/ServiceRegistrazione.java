package com.service;


import java.util.Date;

import com.dao.interfaces.UtenteDAO;
import com.entity.Utente;
import com.factory.DAOFactory;

public class ServiceRegistrazione {

    private DAOFactory daofactory = DAOFactory.getInstance();
    private UtenteDAO utentedao = daofactory.getUtenteDAO(DAOFactory.MYSQL);

    public Boolean effettuaRegistrazione(String email, String password, String areageografica,
            String nickname, Date dataDiNascita, String sesso, String biografia) {

        return utentedao.registraUtente(new Utente(email, password, areageografica, nickname, dataDiNascita, sesso, biografia));

    }

}
