package com.service;

import com.dao.interfaces.UtenteDAO;
import com.entity.Utente;
import com.factory.DAOFactory;

public class ServiceUtente {

    private DAOFactory daofactory = DAOFactory.getInstance();
    private UtenteDAO utentedao = daofactory.getUtenteDAO(DAOFactory.MYSQL);

    public Boolean modificaProfilo(String nickname, String email, String password, String areageografica,
            String biografia, String linkLinkedin, String linkFacebook, String linkInstagram, String linkTwitter) {

        Utente utente = new Utente(nickname, email, password, areageografica, biografia);
        utente.setLinkLinkedin(linkLinkedin);
        utente.setLinkFacebook(linkFacebook);
        utente.setLinkInstagram(linkInstagram);
        utente.setLinkTwitter(linkTwitter);

        return utentedao.apportaModificaProfilo(utente);

    }

    public Utente visualizzaProfilo(String nickname) {

        return utentedao.ottieniProfilo(new Utente(nickname));

    }

    public Utente visualizzaProprioProfilo(String nickname) {

        return utentedao.ottieniProprioProfilo(new Utente(nickname));

    }
}
