import '/backend/api_requests/api_calls.dart';
import '/components/gradient_button/gradient_button_widget.dart';
import '/components/top_nav/top_nav_widget.dart';
import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'informazioni_asta_inversa_t_i_m_e_r_widget.dart'
    show InformazioniAstaInversaTIMERWidget;
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:flutter/material.dart';

class InformazioniAstaInversaTIMERModel
    extends FlutterFlowModel<InformazioniAstaInversaTIMERWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for topNav component.
  late TopNavModel topNavModel;
  // Model for gradientButton component.
  late GradientButtonModel gradientButtonModel;
  // State field(s) for Timer widget.
  int timerMilliseconds = 0;
  String timerValue = StopWatchTimer.getDisplayTime(0, milliSecond: false);
  FlutterFlowTimerController timerController =
      FlutterFlowTimerController(StopWatchTimer(mode: StopWatchMode.countDown));

  // State field(s) for offer widget.
  FocusNode? offerFocusNode;
  TextEditingController? offerController;
  String? Function(BuildContext, String?)? offerControllerValidator;
  // Stores action output result for [Custom Action - verificaScadenza] action in Button widget.
  bool? result;
  // Stores action output result for [Backend Call - API (inviaoffertainversa)] action in Button widget.
  ApiCallResponse? apiResult38n;

  @override
  void initState(BuildContext context) {
    topNavModel = createModel(context, () => TopNavModel());
    gradientButtonModel = createModel(context, () => GradientButtonModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    topNavModel.dispose();
    gradientButtonModel.dispose();
    timerController.dispose();
    offerFocusNode?.dispose();
    offerController?.dispose();
  }
}
