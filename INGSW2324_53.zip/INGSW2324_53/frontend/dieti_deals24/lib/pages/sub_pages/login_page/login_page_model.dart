import '/backend/api_requests/api_calls.dart';
import '/components/main_logo/main_logo_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'login_page_widget.dart' show LoginPageWidget;
import 'package:flutter/material.dart';

class LoginPageModel extends FlutterFlowModel<LoginPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey1 = GlobalKey<FormState>();
  final formKey2 = GlobalKey<FormState>();
  // Model for mainLogo component.
  late MainLogoModel mainLogoModel;
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for Nickname widget.
  FocusNode? nicknameFocusNode;
  TextEditingController? nicknameController;
  String? Function(BuildContext, String?)? nicknameControllerValidator;
  String? _nicknameControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Campo obbligatorio';
    }

    return null;
  }

  // State field(s) for passwordlogin widget.
  FocusNode? passwordloginFocusNode;
  TextEditingController? passwordloginController;
  late bool passwordloginVisibility;
  String? Function(BuildContext, String?)? passwordloginControllerValidator;
  String? _passwordloginControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Campo obbligatorio';
    }

    return null;
  }

  // Stores action output result for [Backend Call - API (accedi)] action in Button widget.
  ApiCallResponse? apiResult5g3;
  // State field(s) for emailAddressCreate widget.
  FocusNode? emailAddressCreateFocusNode;
  TextEditingController? emailAddressCreateController;
  String? Function(BuildContext, String?)?
      emailAddressCreateControllerValidator;
  String? _emailAddressCreateControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Campo obbligatorio';
    }

    if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
      return 'Inserire un email correttamente';
    }
    return null;
  }

  // State field(s) for passwordregister widget.
  FocusNode? passwordregisterFocusNode;
  TextEditingController? passwordregisterController;
  late bool passwordregisterVisibility;
  String? Function(BuildContext, String?)? passwordregisterControllerValidator;
  // State field(s) for passwordregisterconfirm widget.
  FocusNode? passwordregisterconfirmFocusNode;
  TextEditingController? passwordregisterconfirmController;
  late bool passwordregisterconfirmVisibility;
  String? Function(BuildContext, String?)?
      passwordregisterconfirmControllerValidator;

  @override
  void initState(BuildContext context) {
    mainLogoModel = createModel(context, () => MainLogoModel());
    nicknameControllerValidator = _nicknameControllerValidator;
    passwordloginVisibility = false;
    passwordloginControllerValidator = _passwordloginControllerValidator;
    emailAddressCreateControllerValidator =
        _emailAddressCreateControllerValidator;
    passwordregisterVisibility = false;
    passwordregisterconfirmVisibility = false;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    mainLogoModel.dispose();
    tabBarController?.dispose();
    nicknameFocusNode?.dispose();
    nicknameController?.dispose();

    passwordloginFocusNode?.dispose();
    passwordloginController?.dispose();

    emailAddressCreateFocusNode?.dispose();
    emailAddressCreateController?.dispose();

    passwordregisterFocusNode?.dispose();
    passwordregisterController?.dispose();

    passwordregisterconfirmFocusNode?.dispose();
    passwordregisterconfirmController?.dispose();
  }
}
