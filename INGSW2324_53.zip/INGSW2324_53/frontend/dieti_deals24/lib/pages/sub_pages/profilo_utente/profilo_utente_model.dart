import '/backend/api_requests/api_calls.dart';
import '/components/navbar/navbar_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'profilo_utente_widget.dart' show ProfiloUtenteWidget;
import 'package:flutter/material.dart';

class ProfiloUtenteModel extends FlutterFlowModel<ProfiloUtenteWidget> {
  ///  Local state fields for this page.

  bool modify = false;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Backend Call - API (modificaProfilo)] action in IconButton widget.
  ApiCallResponse? apiResult7r2;
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for state widget.
  String? stateValue;
  FormFieldController<String>? stateValueController;
  // State field(s) for emailfield widget.
  FocusNode? emailfieldFocusNode;
  TextEditingController? emailfieldController;
  String? Function(BuildContext, String?)? emailfieldControllerValidator;
  // State field(s) for passwordfield widget.
  FocusNode? passwordfieldFocusNode;
  TextEditingController? passwordfieldController;
  late bool passwordfieldVisibility;
  String? Function(BuildContext, String?)? passwordfieldControllerValidator;
  // State field(s) for myBio widget.
  FocusNode? myBioFocusNode;
  TextEditingController? myBioController;
  String? Function(BuildContext, String?)? myBioControllerValidator;
  // Model for navbar component.
  late NavbarModel navbarModel;

  @override
  void initState(BuildContext context) {
    passwordfieldVisibility = false;
    navbarModel = createModel(context, () => NavbarModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    tabBarController?.dispose();
    emailfieldFocusNode?.dispose();
    emailfieldController?.dispose();

    passwordfieldFocusNode?.dispose();
    passwordfieldController?.dispose();

    myBioFocusNode?.dispose();
    myBioController?.dispose();

    navbarModel.dispose();
  }
}
