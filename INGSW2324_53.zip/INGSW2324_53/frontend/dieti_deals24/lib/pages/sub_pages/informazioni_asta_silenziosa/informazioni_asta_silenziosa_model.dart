import '/backend/api_requests/api_calls.dart';
import '/components/gradient_button/gradient_button_widget.dart';
import '/components/top_nav/top_nav_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'informazioni_asta_silenziosa_widget.dart'
    show InformazioniAstaSilenziosaWidget;
import 'package:flutter/material.dart';

class InformazioniAstaSilenziosaModel
    extends FlutterFlowModel<InformazioniAstaSilenziosaWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for topNav component.
  late TopNavModel topNavModel;
  // Model for gradientButton component.
  late GradientButtonModel gradientButtonModel;
  // State field(s) for offer widget.
  FocusNode? offerFocusNode;
  TextEditingController? offerController;
  String? Function(BuildContext, String?)? offerControllerValidator;
  // Stores action output result for [Custom Action - verificaScadenza] action in Button widget.
  bool? result;
  // Stores action output result for [Backend Call - API (inviaoffertasilenziosa)] action in Button widget.
  ApiCallResponse? apiResult54r;

  @override
  void initState(BuildContext context) {
    topNavModel = createModel(context, () => TopNavModel());
    gradientButtonModel = createModel(context, () => GradientButtonModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    topNavModel.dispose();
    gradientButtonModel.dispose();
    offerFocusNode?.dispose();
    offerController?.dispose();
  }
}
