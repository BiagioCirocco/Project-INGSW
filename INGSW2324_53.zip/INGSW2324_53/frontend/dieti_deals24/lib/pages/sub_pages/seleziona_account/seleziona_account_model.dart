import '/components/compratore/compratore_widget.dart';
import '/components/main_logo/main_logo_widget.dart';
import '/components/venditore/venditore_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'seleziona_account_widget.dart' show SelezionaAccountWidget;
import 'package:flutter/material.dart';

class SelezionaAccountModel extends FlutterFlowModel<SelezionaAccountWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for mainLogo component.
  late MainLogoModel mainLogoModel;
  // Model for venditore component.
  late VenditoreModel venditoreModel;
  // Model for compratore component.
  late CompratoreModel compratoreModel;

  @override
  void initState(BuildContext context) {
    mainLogoModel = createModel(context, () => MainLogoModel());
    venditoreModel = createModel(context, () => VenditoreModel());
    compratoreModel = createModel(context, () => CompratoreModel());
  }

  @override
  void dispose() {
    mainLogoModel.dispose();
    venditoreModel.dispose();
    compratoreModel.dispose();
  }
}
