import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'crea_asta_silenziosa_widget.dart' show CreaAstaSilenziosaWidget;
import 'package:flutter/material.dart';

class CreaAstaSilenziosaModel
    extends FlutterFlowModel<CreaAstaSilenziosaWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));

  // State field(s) for titolo widget.
  FocusNode? titoloFocusNode;
  TextEditingController? titoloController;
  String? Function(BuildContext, String?)? titoloControllerValidator;
  String? _titoloControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Campo obbligatorio';
    }

    return null;
  }

  // State field(s) for myBio widget.
  FocusNode? myBioFocusNode;
  TextEditingController? myBioController;
  String? Function(BuildContext, String?)? myBioControllerValidator;
  String? _myBioControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Campo obbligatorio';
    }

    return null;
  }

  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  DateTime? datePicked;
  // Stores action output result for [Backend Call - API (crea asta silenziosa)] action in Button widget.
  ApiCallResponse? apiResult7to;

  @override
  void initState(BuildContext context) {
    titoloControllerValidator = _titoloControllerValidator;
    myBioControllerValidator = _myBioControllerValidator;
  }

  @override
  void dispose() {
    titoloFocusNode?.dispose();
    titoloController?.dispose();

    myBioFocusNode?.dispose();
    myBioController?.dispose();
  }
}
