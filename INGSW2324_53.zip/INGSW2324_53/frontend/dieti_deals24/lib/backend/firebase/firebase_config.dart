import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyDt4ScudCiXazdJRYjFr15KmsPuxYoK8Dg",
            authDomain: "dietiauction.firebaseapp.com",
            projectId: "dietiauction",
            storageBucket: "dietiauction.appspot.com",
            messagingSenderId: "910493958277",
            appId: "1:910493958277:web:37d71ba6cf7b7a4f15e9ec",
            measurementId: "G-J4JFG4W2TL"));
  } else {
    await Firebase.initializeApp();
  }
}
