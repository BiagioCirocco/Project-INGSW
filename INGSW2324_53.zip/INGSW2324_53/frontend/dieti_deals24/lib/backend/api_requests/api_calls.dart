import 'dart:convert';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class InformazioniastainversaCall {
  static Future<ApiCallResponse> call({
    String? idAsta = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'informazioniastainversa',
      apiUrl: 'http://34.125.242.219:3322/informazioni_asta_inversa/$idAsta',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic informazioniasta(dynamic response) => getJsonField(
        response,
        r'''$.informazioni''',
      );
}

class AccettaoffertasilenziosaCall {
  static Future<ApiCallResponse> call({
    int? idOfferta,
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'accettaoffertasilenziosa',
      apiUrl:
          'http://34.125.242.219:3322/accetta_offerta_silenziosa/$idOfferta',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class CreaAstaInversaCall {
  static Future<ApiCallResponse> call({
    String? immagine = '',
    String? titolo = '',
    String? categoria = '',
    String? descrizione = '',
    String? scadenza = '',
    String? prezzodipartenza = '',
    String? nickname = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'crea asta inversa',
      apiUrl: 'http://34.125.242.219:3322/crea_nuova_asta_inversa',
      callType: ApiCallType.POST,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'immagine': immagine,
        'titolo': titolo,
        'categoria': categoria,
        'descrizione': descrizione,
        'scadenza': scadenza,
        'prezzodipartenza': prezzodipartenza,
        'nickname': nickname,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? statuscreastainversa(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class CreaAstaSilenziosaCall {
  static Future<ApiCallResponse> call({
    String? immagine = '',
    String? titolo = '',
    String? categoria = '',
    String? descrizione = '',
    String? scadenza = '',
    String? nickname = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'crea asta silenziosa',
      apiUrl: 'http://34.125.242.219:3322/crea_nuova_asta_silenziosa',
      callType: ApiCallType.POST,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'immagine': immagine,
        'titolo': titolo,
        'categoria': categoria,
        'descrizione': descrizione,
        'scadenza': scadenza,
        'nickname': nickname,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? statuscreastasilenziosa(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class InviaoffertainversaCall {
  static Future<ApiCallResponse> call({
    String? nickname = '',
    String? idAsta = '',
    String? offerta = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'inviaoffertainversa',
      apiUrl: 'http://34.125.242.219:3322/invia_offerta_inversa',
      callType: ApiCallType.POST,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'nickname': nickname,
        'id_asta': idAsta,
        'offerta': offerta,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class InviaoffertasilenziosaCall {
  static Future<ApiCallResponse> call({
    String? nickname = '',
    String? idAsta = '',
    String? offerta = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'inviaoffertasilenziosa',
      apiUrl: 'http://34.125.242.219:3322/invia_offerta_silenziosa',
      callType: ApiCallType.POST,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'nickname': nickname,
        'id_asta': idAsta,
        'offerta': offerta,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class InformazioniastasilenziosaCall {
  static Future<ApiCallResponse> call({
    String? idAsta = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'informazioniastasilenziosa',
      apiUrl:
          'http://34.125.242.219:3322/informazioni_asta_silenziosa/$idAsta',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic informazioniasta(dynamic response) => getJsonField(
        response,
        r'''$.informazioni''',
      );
}

class InformazioniMiaAstasilenziosaCall {
  static Future<ApiCallResponse> call({
    String? idAsta = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'informazioni mia astasilenziosa ',
      apiUrl:
          'http://34.125.242.219:3322/informazioni_mia_asta_silenziosa/$idAsta',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic informazioniasta(dynamic response) => getJsonField(
        response,
        r'''$.informazioni''',
      );
  static List? offerte(dynamic response) => getJsonField(
        response,
        r'''$.informazioni.offerta''',
        true,
      ) as List?;
}

class OttieniastainversaCall {
  static Future<ApiCallResponse> call({
    String? categoria = '',
    String? search = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'ottieniastainversa',
      apiUrl: 'http://34.125.242.219:3322/aste_inverse',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'search': search,
        'categoria': categoria,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List? asteinverse(dynamic response) => getJsonField(
        response,
        r'''$.aste''',
        true,
      ) as List?;
}

class OttieniastasilenziosaCall {
  static Future<ApiCallResponse> call({
    String? categoria = '',
    String? search = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'ottieniastasilenziosa',
      apiUrl: 'http://34.125.242.219:3322/aste_silenziose',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'search': search,
        'categoria': categoria,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List? asteinverse(dynamic response) => getJsonField(
        response,
        r'''$.aste''',
        true,
      ) as List?;
}

class OttieniprofiloCall {
  static Future<ApiCallResponse> call({
    String? nickname = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'ottieniprofilo',
      apiUrl: 'http://34.125.242.219:3322/profilo/$nickname',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic profilo(dynamic response) => getJsonField(
        response,
        r'''$.status''',
      );
}

class MioprofiloCall {
  static Future<ApiCallResponse> call({
    String? nickname = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'mioprofilo',
      apiUrl: 'http://34.125.242.219:3322/mio_profilo/$nickname',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic profilo(dynamic response) => getJsonField(
        response,
        r'''$.status''',
      );
  static List? asta(dynamic response) => getJsonField(
        response,
        r'''$.status.asta''',
        true,
      ) as List?;
}

class OttieniAggiornamentIInversaCall {
  static Future<ApiCallResponse> call({
    String? nickname = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'ottieni aggiornament iInversa',
      apiUrl: 'http://34.125.242.219:3322/aggiornamenti_inversa/$nickname',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List? aggiornamenti(dynamic response) => getJsonField(
        response,
        r'''$.aggiornamenti''',
        true,
      ) as List?;
}

class OttieniAggiornamentSilenziosaCall {
  static Future<ApiCallResponse> call({
    String? nickname = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'ottieni aggiornament silenziosa',
      apiUrl: 'http://34.125.242.219:3322/aggiornamenti_silenziosa/$nickname',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List? aggiornamenti(dynamic response) => getJsonField(
        response,
        r'''$.aggiornamenti''',
        true,
      ) as List?;
}

class OttienicategorieCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'ottienicategorie',
      apiUrl: 'http://34.125.242.219:3322/ottieni_categorie_inversa',
      callType: ApiCallType.GET,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List<String>? categorie(dynamic response) => (getJsonField(
        response,
        r'''$.categorie''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  static String? initial(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.categorie[0]''',
      ));
}

class AccediCall {
  static Future<ApiCallResponse> call({
    String? nickname = '',
    String? password = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'accedi',
      apiUrl: 'http://34.125.242.219:3322/accedi',
      callType: ApiCallType.POST,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'nickname': nickname,
        'password': password,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? statuslogin(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class RegistratiCall {
  static Future<ApiCallResponse> call({
    String? email = '',
    String? password = '',
    String? areaGeografica = '',
    String? nickname = '',
    String? dataDiNascita = '',
    String? sesso = '',
    String? biografia = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'registrati',
      apiUrl: 'http://34.125.242.219:3322/registrati',
      callType: ApiCallType.POST,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'email': email,
        'password': password,
        'area_geografica': areaGeografica,
        'nickname': nickname,
        'data_di_nascita': dataDiNascita,
        'sesso': sesso,
        'biografia': biografia,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? statusregister(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class ModificaProfiloCall {
  static Future<ApiCallResponse> call({
    String? email = '',
    String? password = '',
    String? areaGeografica = '',
    String? nickname = '',
    String? biografia = '',
    String? linkLinkedin = '',
    String? linkFacebook = '',
    String? linkTwitter = '',
    String? linkInstagram = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'modificaProfilo',
      apiUrl: 'http://34.125.242.219:3322/modifica_profilo',
      callType: ApiCallType.POST,
      headers: {
        'ngrok-skip-browser-warning': '1234',
      },
      params: {
        'email': email,
        'password': password,
        'area_geografica': areaGeografica,
        'nickname': nickname,
        'biografia': biografia,
        'link_linkedin': linkLinkedin,
        'link_facebook': linkFacebook,
        'link_instagram': linkInstagram,
        'link_twitter': linkTwitter,
      },
      bodyType: BodyType.X_WWW_FORM_URL_ENCODED,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? statusregister(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
}

class CountriesCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'countries',
      apiUrl: 'https://restcountries.com/v3.1/all',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static List<String>? namecommon(dynamic response) => (getJsonField(
        response,
        r'''$[:].name.common''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    return isList ? '[]' : '{}';
  }
}
