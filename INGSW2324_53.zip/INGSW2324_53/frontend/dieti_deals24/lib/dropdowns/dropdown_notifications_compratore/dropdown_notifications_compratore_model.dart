import '/flutter_flow/flutter_flow_util.dart';
import 'dropdown_notifications_compratore_widget.dart'
    show DropdownNotificationsCompratoreWidget;
import 'package:flutter/material.dart';

class DropdownNotificationsCompratoreModel
    extends FlutterFlowModel<DropdownNotificationsCompratoreWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
