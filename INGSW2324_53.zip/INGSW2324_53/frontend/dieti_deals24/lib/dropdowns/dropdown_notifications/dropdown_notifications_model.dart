import '/flutter_flow/flutter_flow_util.dart';
import 'dropdown_notifications_widget.dart' show DropdownNotificationsWidget;
import 'package:flutter/material.dart';

class DropdownNotificationsModel
    extends FlutterFlowModel<DropdownNotificationsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
