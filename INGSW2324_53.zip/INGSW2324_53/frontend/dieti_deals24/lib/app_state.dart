import 'package:flutter/material.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _nickname = '';
  String get nickname => _nickname;
  set nickname(String value) {
    _nickname = value;
  }

  String _accountType = '';
  String get accountType => _accountType;
  set accountType(String value) {
    _accountType = value;
  }

  String _linkLinkedin = '';
  String get linkLinkedin => _linkLinkedin;
  set linkLinkedin(String value) {
    _linkLinkedin = value;
  }

  String _linkTwitter = '';
  String get linkTwitter => _linkTwitter;
  set linkTwitter(String value) {
    _linkTwitter = value;
  }

  String _linkInstagram = '';
  String get linkInstagram => _linkInstagram;
  set linkInstagram(String value) {
    _linkInstagram = value;
  }

  String _linkFacebook = '';
  String get linkFacebook => _linkFacebook;
  set linkFacebook(String value) {
    _linkFacebook = value;
  }
}
