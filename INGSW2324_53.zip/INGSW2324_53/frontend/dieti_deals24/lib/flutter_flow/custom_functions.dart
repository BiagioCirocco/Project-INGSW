import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/auth/custom_auth/auth_util.dart';

bool? newCustomFunction(
  String? offerta,
  String? prezzocorrente,
) {
  if (offerta == null || prezzocorrente == null) {
    return null;
  }
  final double offertaValue = double.tryParse(offerta) ?? 0.0;
  final double prezzoValue = double.tryParse(prezzocorrente) ?? 0.0;
  return offertaValue < prezzoValue;
}

String? base64image(FFUploadedFile? imageByte) {
  List<int>? imageBytes = imageByte!.bytes;
  if (imageBytes != null) {
    String base64Image = base64Encode(imageBytes);
    return base64Image;
  }
}

String? estragiornimancanti(String scadenza) {
  DateTime today = DateTime.now();
  DateTime futureDate = DateTime.parse(scadenza);

  int difference = futureDate.difference(today).inDays;
  return difference.toString();
}

int estraidifferenzainmillisecondi(String scadenza) {
  // la tua data e ora in ingresso
  DateTime now = DateTime.now();
  DateTime futureDateTime = DateTime.parse(scadenza);

  Duration difference = futureDateTime.difference(now);

  int differenceInMilliseconds = difference.inMilliseconds;
  return differenceInMilliseconds;
}
