import '/flutter_flow/flutter_flow_util.dart';
import 'main_logo_widget.dart' show MainLogoWidget;
import 'package:flutter/material.dart';

class MainLogoModel extends FlutterFlowModel<MainLogoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
