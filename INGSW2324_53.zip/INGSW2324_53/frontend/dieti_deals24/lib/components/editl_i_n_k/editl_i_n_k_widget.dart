import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'editl_i_n_k_model.dart';
export 'editl_i_n_k_model.dart';

class EditlINKWidget extends StatefulWidget {
  const EditlINKWidget({
    super.key,
    required this.link,
    required this.social,
  });

  final String? link;
  final String? social;

  @override
  State<EditlINKWidget> createState() => _EditlINKWidgetState();
}

class _EditlINKWidgetState extends State<EditlINKWidget> {
  late EditlINKModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EditlINKModel());

    _model.linkController ??= TextEditingController(text: widget.link);
    _model.linkFocusNode ??= FocusNode();

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(20.0, 16.0, 20.0, 16.0),
      child: TextFormField(
        controller: _model.linkController,
        focusNode: _model.linkFocusNode,
        onFieldSubmitted: (_) async {
          logFirebaseEvent('EDITL_I_N_K_link_ON_TEXTFIELD_SUBMIT');
          if (widget.social == 'twitter') {
            logFirebaseEvent('link_update_app_state');
            setState(() {
              FFAppState().linkTwitter = _model.linkController.text;
            });
          } else if (widget.social == 'facebook') {
            logFirebaseEvent('link_update_app_state');
            setState(() {
              FFAppState().linkFacebook = _model.linkController.text;
            });
          } else if (widget.social == 'instagram') {
            logFirebaseEvent('link_update_app_state');
            setState(() {
              FFAppState().linkInstagram = _model.linkController.text;
            });
          } else {
            logFirebaseEvent('link_update_app_state');
            setState(() {
              FFAppState().linkLinkedin = _model.linkController.text;
            });
          }
        },
        textCapitalization: TextCapitalization.words,
        textInputAction: TextInputAction.send,
        obscureText: false,
        decoration: InputDecoration(
          labelText: 'Link (premi invio per apportare le modifiche)',
          labelStyle: FlutterFlowTheme.of(context).labelMedium.override(
                fontFamily: FlutterFlowTheme.of(context).labelMediumFamily,
                letterSpacing: 0.0,
                useGoogleFonts: GoogleFonts.asMap().containsKey(
                    FlutterFlowTheme.of(context).labelMediumFamily),
              ),
          hintStyle: FlutterFlowTheme.of(context).labelMedium.override(
                fontFamily: FlutterFlowTheme.of(context).labelMediumFamily,
                letterSpacing: 0.0,
                useGoogleFonts: GoogleFonts.asMap().containsKey(
                    FlutterFlowTheme.of(context).labelMediumFamily),
              ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: FlutterFlowTheme.of(context).alternate,
              width: 2.0,
            ),
            borderRadius: BorderRadius.circular(8.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: FlutterFlowTheme.of(context).primary,
              width: 2.0,
            ),
            borderRadius: BorderRadius.circular(8.0),
          ),
          errorBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: FlutterFlowTheme.of(context).error,
              width: 2.0,
            ),
            borderRadius: BorderRadius.circular(8.0),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: FlutterFlowTheme.of(context).error,
              width: 2.0,
            ),
            borderRadius: BorderRadius.circular(8.0),
          ),
          filled: true,
          fillColor: FlutterFlowTheme.of(context).secondaryBackground,
          contentPadding: const EdgeInsetsDirectional.fromSTEB(20.0, 24.0, 0.0, 24.0),
        ),
        style: FlutterFlowTheme.of(context).bodyMedium.override(
              fontFamily: FlutterFlowTheme.of(context).bodyMediumFamily,
              letterSpacing: 0.0,
              useGoogleFonts: GoogleFonts.asMap()
                  .containsKey(FlutterFlowTheme.of(context).bodyMediumFamily),
            ),
        cursorColor: FlutterFlowTheme.of(context).primary,
        validator: _model.linkControllerValidator.asValidator(context),
      ),
    );
  }
}
