import '/flutter_flow/flutter_flow_util.dart';
import 'editl_i_n_k_widget.dart' show EditlINKWidget;
import 'package:flutter/material.dart';

class EditlINKModel extends FlutterFlowModel<EditlINKWidget> {
  ///  Local state fields for this component.

  String provacom = 'nulla';

  ///  State fields for stateful widgets in this component.

  // State field(s) for link widget.
  FocusNode? linkFocusNode;
  TextEditingController? linkController;
  String? Function(BuildContext, String?)? linkControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    linkFocusNode?.dispose();
    linkController?.dispose();
  }
}
