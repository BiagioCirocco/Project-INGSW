import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'compratore_model.dart';
export 'compratore_model.dart';

class CompratoreWidget extends StatefulWidget {
  const CompratoreWidget({super.key});

  @override
  State<CompratoreWidget> createState() => _CompratoreWidgetState();
}

class _CompratoreWidgetState extends State<CompratoreWidget> {
  late CompratoreModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CompratoreModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8.0),
      child: Image.asset(
        Theme.of(context).brightness == Brightness.dark
            ? 'assets/images/Vector_(1).png'
            : 'assets/images/Vector_(1).png',
        width: 58.0,
        height: 35.0,
        fit: BoxFit.fitWidth,
      ),
    );
  }
}
