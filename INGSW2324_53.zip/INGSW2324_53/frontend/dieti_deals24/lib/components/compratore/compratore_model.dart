import '/flutter_flow/flutter_flow_util.dart';
import 'compratore_widget.dart' show CompratoreWidget;
import 'package:flutter/material.dart';

class CompratoreModel extends FlutterFlowModel<CompratoreWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
