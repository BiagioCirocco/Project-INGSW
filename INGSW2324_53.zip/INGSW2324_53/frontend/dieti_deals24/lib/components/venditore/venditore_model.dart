import '/flutter_flow/flutter_flow_util.dart';
import 'venditore_widget.dart' show VenditoreWidget;
import 'package:flutter/material.dart';

class VenditoreModel extends FlutterFlowModel<VenditoreWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
