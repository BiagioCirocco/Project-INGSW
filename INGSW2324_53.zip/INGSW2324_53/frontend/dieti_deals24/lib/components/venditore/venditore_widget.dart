import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'venditore_model.dart';
export 'venditore_model.dart';

class VenditoreWidget extends StatefulWidget {
  const VenditoreWidget({super.key});

  @override
  State<VenditoreWidget> createState() => _VenditoreWidgetState();
}

class _VenditoreWidgetState extends State<VenditoreWidget> {
  late VenditoreModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VenditoreModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8.0),
      child: Image.asset(
        Theme.of(context).brightness == Brightness.dark
            ? 'assets/images/Vector.png'
            : 'assets/images/Vector.png',
        width: 50.0,
        height: 50.0,
        fit: BoxFit.fitWidth,
      ),
    );
  }
}
