import '/flutter_flow/flutter_flow_util.dart';
import 'navbar_widget.dart' show NavbarWidget;
import 'package:flutter/material.dart';

class NavbarModel extends FlutterFlowModel<NavbarWidget> {
  ///  Local state fields for this component.

  String? provadacacnellare;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
